from .Base import PageObject


class index(PageObject):
    pass


class create(PageObject):
    pass


class update(PageObject):
    pass
