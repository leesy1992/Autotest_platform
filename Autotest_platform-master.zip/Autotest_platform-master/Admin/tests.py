from selenium import webdriver

# Create your tests here.




driver.get('http://www.baidu.com')
print(driver.title)
